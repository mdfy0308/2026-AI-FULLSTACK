package com.thejoa703.security;

import java.time.Instant;
import java.util.Date;
import java.util.Map;

import javax.crypto.SecretKey;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
 
@Component
public class JwtProvider {
    private final JwtProperties props;  
    private final SecretKey key;   
 
    public JwtProvider(JwtProperties props) {
        this.props = props;
        this.key = Keys.hmacShaKeyFor(props.getSecret().getBytes());  
    }
  
    public String createAccessToken(String subject, Map<String, Object> claims) {  
        Instant now = Instant.now();
        Instant exp = now.plusSeconds(props.getAccessTokenExpSeconds());
        return Jwts.builder()
                .setIssuer(props.getIssuer())  
                .setSubject(subject)     
                .addClaims(claims)        
                .setIssuedAt(Date.from(now))   
                .setExpiration(Date.from(exp))  
                .signWith(key, SignatureAlgorithm.HS256)   
                .compact();
    }
     
    public String createRefreshToken(String subject) {   
        Instant now = Instant.now();
        Instant exp = now.plusSeconds(props.getRefreshTokenExpSeconds());   
        return Jwts.builder()
                .setIssuer(props.getIssuer())
                .setSubject(subject)
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(exp))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    } 
    public Jws<Claims> parse(String token) {  
        return Jwts.parserBuilder()
                .setSigningKey(key)   
                .requireIssuer(props.getIssuer())   
                .build()
                .parseClaimsJws(token);
    }
}
