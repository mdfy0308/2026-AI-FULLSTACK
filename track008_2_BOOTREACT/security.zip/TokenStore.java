package com.thejoa703.security;

import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate; // 🔍 템플릿 변경
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@RequiredArgsConstructor
public class TokenStore {
 
    private final StringRedisTemplate stringRedisTemplate; 
 
    public void saveRefreshToken(String userId, String token, long ttlSeconds) {
        String key = buildKey(userId); 
        stringRedisTemplate.opsForValue().set(key, token, ttlSeconds, TimeUnit.SECONDS);
    }
 
    public String getRefreshToken(String userId) {
        String key = buildKey(userId);
        return stringRedisTemplate.opsForValue().get(key);
    }
 
    public void deleteRefreshToken(String userId) {
        String key = buildKey(userId);
        stringRedisTemplate.delete(key);
    }
 
    private String buildKey(String userId) {
        return "refresh:" + userId;
    }
}