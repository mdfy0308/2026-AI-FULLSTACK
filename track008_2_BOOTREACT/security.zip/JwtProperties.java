package com.thejoa703.security;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import lombok.Data;

 
@Data
@Configuration   
@ConfigurationProperties(prefix = "jwt")   
public class JwtProperties {
    private String issuer;  
    private String secret;  
    private int accessTokenExpSeconds;   
    private int refreshTokenExpSeconds;  
    private String header;  
    private String prefix;  
}