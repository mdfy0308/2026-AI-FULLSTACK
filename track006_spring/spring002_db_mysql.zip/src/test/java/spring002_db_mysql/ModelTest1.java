package spring002_db_mysql;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.the703.dao.TestMapper;
import com.the703.dao.UserInfoMapper;
import com.the703.dto.UserInfoDto;

@RunWith(SpringJUnit4ClassRunner.class) // 1. spring ����
@ContextConfiguration(locations = "classpath:config/root-context.xml") // 2. ��������


public class ModelTest1 {
	
		@Autowired ApplicationContext context; // 3. bean(�������� �����ϴ� ��ü) ����~�Ҹ�
		@Autowired DataSource dataSource;
		@Autowired SqlSession sqlSession;
		@Autowired TestMapper test;
		@Autowired UserInfoMapper userinfo;
		
		@Test
		public void test6() {
			
			//5. ����
//			System.out.println( userinfo.delete(6) );
			
			//4. ����
//			UserInfoDto dto = new UserInfoDto();
//			dto.setName("gamma"); dto.setAge(70); dto.setNo(5);
//			System.out.println( userinfo.update(dto) );
			
			//3. �Ѹ��˻�
			System.out.println( userinfo.select(1) );
			
			//2. ����
//			UserInfoDto dto = new UserInfoDto();
//			dto.setName("delta"); dto.setAge(10);
//			System.out.println( userinfo.insert(dto) );
			
			//1. ��ü�˻�
			System.out.println( userinfo.selectAll());
		}
		
		
		@Ignore // @Test
		public void text1() { System.out.println( context ); }
		
		@Ignore 
		public void test2() { System.out.println( dataSource ); }
		
		@Ignore 
		public void test3() { System.out.println( sqlSession ); }
		
		@Ignore // @Test
		public void test4() { System.out.println( test.now()); }

}
