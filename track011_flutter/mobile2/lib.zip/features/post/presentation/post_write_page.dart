import 'dart:typed_data';
import 'package:flutter/foundation.dart'; // 기본 유틸
import 'package:flutter/material.dart'; // ui 컴포넌트 모음
import 'package:flutter_riverpod/flutter_riverpod.dart'; // riverpod : 전역상태관리
import 'package:image_picker/image_picker.dart'; // 이미지 선택
import '../data/board_provider.dart'; // 전역상태 + 서버연동 데이터 가져오는 기능   (boardProvider)
import '../../auth/data/auth_provider.dart'; // 사용자 정보, 인증 상태 프로바이더

class PostWritePage extends ConsumerStatefulWidget { // ## ConsumerStatefulWidget
  const PostWritePage({super.key});

  @override
  ConsumerState<PostWritePage> createState() => _PostWritePageState();
}

class _PostWritePageState extends ConsumerState<PostWritePage> {
  final _contentController = TextEditingController(); // 입력 컨트롤러
  final _hashtagController = TextEditingController();
  
  final ImagePicker _picker = ImagePicker(); // 이미지 선택
  List<XFile> _selectedImages = [];
  
  final Map<String, Uint8List> _imageBytesCache = {};

  @override
  void dispose() { // ## 위젯 메모리 해제
    _contentController.dispose();
    _hashtagController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    final List<XFile> images = await _picker.pickMultiImage(); // 다중 이미지 선택
    if (images.isNotEmpty) {
      for (var image in images) { // 선택된 파일들
        final bytes = await image.readAsBytes(); // 바이트 데이터 추출
        _imageBytesCache[image.path] = bytes; // 경로를 바이트 저장
      }
      setState(() { // ui 그리기
        _selectedImages = images;
      });
    }
  }

  void _handleSubmit() async {
    final content = _contentController.text.trim(); // 본문 텍스트 공백 제거
    final hashtags = _hashtagController.text.trim();
    
    // 유저 ID 안전 추출
    final user = ref.read(authProvider).user; // ## redux + saga = provider 기능의 user 가져오기
    final rawId = user?['id'] ?? user?['userId'] ?? user?['memberId'] ?? '1';
    final userId = rawId.toString();

    if (content.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('내용을 입력해주세요.')),
      );
      return;
    }

    final success = await ref.read(boardProvider.notifier).createPost(
      userId: userId,
      content: content,
      hashtags: hashtags,
      imageFiles: _selectedImages,
    );

    if (success && mounted) {
      // 등록 성공 알림 띄우기 (화면 상단/하단 SnackBar)
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('게시글이 성공적으로 등록되었습니다! 🎉'),
          duration: Duration(seconds: 2),
          behavior: SnackBarBehavior.floating, // 바닥에 붙지 않고 떠있는 깔끔한 스타일
        ),
      );
      Navigator.pop(context); // ## 현재화면 닫고 전화면 이동
    }
  }

  ///////////////////////////////////////////////////////////

  @override
  Widget build(BuildContext context) {
    return Scaffold( // # 앱의 기본 골격
      appBar: AppBar(title: const Text('새 글 작성')), // 상단앱바
      body: Padding( // # 부품 Padding: 여백레이아웃
        padding: const EdgeInsets.all(16.0), // 4개 여백
        child: ListView( // # 부품 ListView : 스크롤 가능한 리스트 뷰
          children: [
            TextField( // 입력폼 위젯
              controller: _contentController, // 컨트롤러 바인딩
              decoration: const InputDecoration(labelText: '내용 입력'), // 라벨
              maxLines: 5, // 줄 공간 확보
            ),
            const SizedBox(height: 12), // 세로사이즈 12px
            TextField(
              controller: _hashtagController,
              decoration: const InputDecoration(labelText: '해시태그 (예: #flutter, #spring)'),
            ),
            const SizedBox(height: 20),
            
            ElevatedButton.icon(
              onPressed: _pickImages,
              icon: const Icon(Icons.image),
              label: Text('이미지 첨부하기 (${_selectedImages.length}장 선택됨)'),
            ),
            const SizedBox(height: 12),

            if (_selectedImages.isNotEmpty)
              SizedBox(
                height: 100, // 프리뷰 영역 100px 제한 ##
                child: ListView.builder( 
                  scrollDirection: Axis.horizontal,
                  itemCount: _selectedImages.length,
                  itemBuilder: (context, index) {
                    final image = _selectedImages[index];
                    final bytes = _imageBytesCache[image.path];

                    return Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: Stack(
                        children: [
                          bytes != null
                              ? Image.memory(bytes, width: 100, height: 100, fit: BoxFit.cover)
                              : Container(width: 100, height: 100, color: Colors.grey[300]),
                          Positioned(
                            top: 0,
                            right: 0,
                            child: IconButton(
                              icon: const Icon(Icons.remove_circle, color: Colors.red),
                              onPressed: () {
                                setState(() {
                                  _imageBytesCache.remove(image.path);
                                  _selectedImages.removeAt(index);
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),

            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white),
                onPressed: _handleSubmit,
                child: const Text('등록하기', style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}